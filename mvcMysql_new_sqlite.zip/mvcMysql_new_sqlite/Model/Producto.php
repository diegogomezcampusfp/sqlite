<?php

class Producto
{//encapsulamiento
    function __construct($id, $nombre,$unidades, $precio)
	{
		$this->setId($id);
		$this->setNombre($nombre);
		$this->setUnidades($unidades);
		$this->setPrecio($precio);		
	}
 
	public function getId(){
		return $this->id;
	}
 
	public function setId($id){
		$this->id = $id;
	}
 
	public function getNombre(){
		return $this->nombre;
	}
 
	public function setNombre($nombre){
		$this->nombre = $nombre;
	}
 
	public function getUnidades(){
		return $this->unidades;
	}
 
	public function setUnidades($unidades){
		$this->unidades = $unidades;
	}
 
	public function getPrecio(){
 
		return $this->precio;
	}
 
	public function setPrecio($precio){
		$this->precio = $precio;
		
		//cierra else
 
	}//cierra setEstado

    public static function save($producto)
    {
        $conexion=Db::getConnect();
        
        $insertar=$conexion->prepare('INSERT INTO tabla VALUES (default, :nombre, :unidades, :precio)');//consulta paramétrica
        $insertar->bindValue('nombre',$producto->getNombre());
        $insertar->bindValue('unidades',$producto->getUnidades());
        $insertar->bindValue('precio',$producto->getPrecio());
        $insertar->execute();
    }
}//cierra clase
