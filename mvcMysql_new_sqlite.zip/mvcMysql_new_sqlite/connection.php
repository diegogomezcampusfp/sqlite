<?php

class Db
{
    //atributos

    //constructor
    function __construct()
    {

    }
    //getter y setter

    //metodos
    public static function getConnect()
    {
        $conexion=new PDO('sqlite:baseDiego.db);//cambiar la fuente de datos
        var_dump($conexion);
        return $conexion;
    }
}