<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="skeleton/css/skeleton.css">
    <title>Document</title>
</head>
<body>
    <h2>CRUD</h2>
    <form action="?controller=producto&action=save" method="post"> 
  <div class="row">
    <div class="six columns">
      <label for="exampleEmailInput">Nombre</label>
      <input class="u-full-width" type="text" placeholder="" id="exampleEmailInput" name='nombre'>
    </div>
    <div class="six columns">
    <div class="six columns">
      <label for="exampleEmailInput">Unidades</label>
      <input class="u-full-width" type="number" placeholder="" id="exampleEmailInput" name='unidades'>
      <div class="six columns">
      <label for="exampleEmailInput">Precio</label>
      <input class="u-full-width" type="number" step="0.1" placeholder="" id="exampleEmailInput" name='precio'>
    </div>
    </div>
    </div>
  </div>
  <input type="submit">
</form>


    <?php
    require_once('connection.php');
    if (isset($_GET['controller'])&&isset($_GET['action'])) {
        
        $controller=$_GET['controller'];
        $action=$_GET['action'];
    }
    else {
        $controller="producto";
        $action="index";
    }
    require_once('Views/Layouts/layout.php');

    echo $controller;
    echo $action;
    ?>
</body>
</html>