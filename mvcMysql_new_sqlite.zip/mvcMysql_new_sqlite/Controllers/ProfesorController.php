<?php
class ProfesorController
{
    //atributos
    //constructor
    //getters y setters
    //otros
    function __constructor()
    {

    }

    function index()
    {
        require_once('Views/Profesor/bienvenido.php');
    }
    
    function register()
    {
        require_once('Views/Profesor/register.php');
    }
}//cierra clase