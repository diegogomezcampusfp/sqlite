<?php
class CursoController
{
    //atributos
    //constructor
    //getters y setters
    //otros
    function __constructor()
    {

    }

    function index()
    {
        require_once('Views/Curso/bienvenido.php');
    }
    
    function register()
    {
        require_once('Views/Curso/register.php');
    }
}//cierra clase